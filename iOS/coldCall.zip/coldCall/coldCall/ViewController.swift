//
//  ViewController.swift
//  coldCall
//
//  Created by dalia icedo on 3/7/17.
//  Copyright © 2017 dalia icedo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var nameLbl: UILabel!
    
    let nameList = ["Moose", "Macchiato", "Mocha", "Shadow"]
    
    @IBAction func coldCallBtn(_ sender: UIButton) {
        let num = Int(arc4random_uniform(UInt32(nameList.count)))
        nameLbl.text = nameList[num]
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

