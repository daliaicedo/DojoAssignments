from __future__ import unicode_literals

from django.apps import AppConfig


class NinjaGConfig(AppConfig):
    name = 'ninja_g'
